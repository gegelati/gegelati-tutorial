#include "pendulum_wrapper.h"

const std::vector<double> PendulumWrapper::actions{ 0.0 };

PendulumWrapper::PendulumWrapper() : LearningEnvironment(actions.size())
{
}

std::vector<std::reference_wrapper<const Data::DataHandler>> PendulumWrapper::getDataSources()
{
	return std::vector<std::reference_wrapper<const Data::DataHandler>>();
}

void PendulumWrapper::reset(size_t seed, Learn::LearningMode mode, uint16_t iterationNumber, uint64_t generationNumber)
{
}

void PendulumWrapper::doAction(double actionID)
{

}

double PendulumWrapper::getScore(void) const
{
	return 0.0;
}

bool PendulumWrapper::isTerminal(void) const
{
	return false;
}
