# GEGELATI Tutorial

This repository contains files needed to support a hands-on tutorial for GEGELATI.